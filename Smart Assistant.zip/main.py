import tkinter as tk
import keyboard
import speech_recognition as sr
from AppOpener import open 
import time
#from mttkinter import mtTkinter 
global window
window = tk.Tk()
window.geometry = ("300x200")
# getting screen width and height of display
width = window.winfo_screenwidth()
height = window.winfo_screenheight()
# setting tkinter window size

w = 800  # width for the Tk root
h = 650  # height for the Tk root

# get screen width and height
ws = window.winfo_screenwidth()  # width of the screen
hs = window.winfo_screenheight()  # height of the screen

# calculate x and y coordinates for the Tk root window
x = (ws / ws) - (w / w)
y = (hs / hs) - (h / h)

## set the attributes and dimensions of the screen and where it is placed
window.geometry=('%dx%d+%d+%d' % ((int("300")), (int("200")), x, y)) #sets the popup window to be in the top left of the screen
window.attributes('-topmost', 1) # sets the window to always be on top
window.attributes('-alpha',0.7) # sets the transparency to full

window.wm_state ('iconic')
window.title("") # names the window
tk.Label(window, text="Hello, I am your digital smart assistant, how may I help?").grid(column=1, row=3) # adds text to the window

def recognition(): #defines a new funcion that will be used for speech recognition
    global window
    window.wm_state('normal')
    #window.attributes('-topmost', 1) # sets the window to always be on top
    #window.attributes('-alpha',0.5) # sets the transparency to half
    r = sr.Recognizer() # creates new instance which represents a collection of speech recognition
    
    with sr.Microphone() as source: # sets the microphone on the computer as a source   
        r.adjust_for_ambient_noise(source) # adjusts the recording for aimbient noise from the surroundings 
        print ("I'm listening") # tells the user that the program is ready for a command
        audio = r.listen(source) # records a phrase and stores it in the variable audio

        print ("analysing") # tells the user that the computer is working out what they are saying

        try: # the computer will try to go down this route first but if it cant due to encountering an error it will go down an alternate route 
            compare = r.recognize_google(audio) # stores what the user says in a variable 
            comapre = compare.lower()
            print (compare) #outputs what the user says 
            #splitting the string
            words = compare.split()
            #slicing the list (negative index means index from the end)
            #-1 means the last element of the list
            endword = (words[-1]) 
            open (endword, match_closest= True, output= True) 
        except Exception as e: # this is an alternate route that it would go down 
            print ("I could not understand, please try again")  # lets the user know that it could not recognise what they are saying
        time.sleep(5) # pauses the program to allow for the user to read the text 
        window.wm_state ('iconic') # sets the window back to minimised when it is no longer needed 
        

    

# Check if ctrl+1 was pressed
keyboard.add_hotkey('ctrl+1', recognition) # adds a hotkey and runs a function when it is pressed 
window.mainloop() # makes a root window appear when the program is run 
a=input()